#require 'redmine/menu_manager.rb'
#include MenuManager
class LeaveController < ApplicationController
  def set_quota
    @leave_quota = Quota.all
    #@quota_user = User.where(:admin => 1 && :type => 'user').all
    @quota_user = User.where("admin = #{0} && type = 'user' ").all
  end
  def admin_side
    @pending = Leave.where(:status => "Pending").count
    @approved = Leave.where(:status => "Approved").count
    @disapproved = Leave.where(:status => "Disapproved").count
    render 'leave/admin_side' and return
  end

  def overview
    current_id = session[:user_id]
    @year_start = Date.today.beginning_of_year #Leaves by year
    @year_end = Date.today.end_of_year
    @month_start = Date.today.beginning_of_month #Leaves by month
    @month_end = Date.today.end_of_month   
    @date_today = Date.today
    @leave_year = Leave.find_by_sql("SELECT SUM(myview.days) AS no_leaves FROM (SELECT DATEDIFF(end_date, start_date) AS days FROM leaves WHERE user_id= #{current_id}  AND start_date >= '#{@year_start}' AND end_date <= '#{@date_today}') AS myview")
    @leave_month = Leave.find_by_sql("SELECT SUM(myview.days) AS no_leaves FROM (SELECT DATEDIFF(end_date, start_date) AS days FROM leaves WHERE user_id= #{current_id} AND start_date >= '#{@month_start}' AND end_date <= '#{@month_end}') AS myview")
    @by_month = @leave_month[0].no_leaves
    @by_year = @leave_year[0].no_leaves
    @leave_view = Leave.where(:user_id => current_id).order("status DESC")
    render 'leave/overview' #END OF USER SIDE CODE
  end

  def new
    @user_name = User.current.name
    current_id = session[:user_id]
    manager_role = Role.where("name = 'Manager'").first
    manager_role = MemberRole.where("role_id = #{manager_role.id}").all
    @managers_name = [] 
    manager_role.each do |user| 
      @managers_name.push(user.member_id)
    end  
    @manager_table =[]
    @member_id = Member.find(@managers_name)
    @member_id.each do |mg|
      if mg.user_id != current_id
        @manager_table.push(mg.user_id)
      end
    end
    @year_start = Date.today.beginning_of_year #Leaves by year
    @year_end = Date.today.end_of_year
    @month_start = Date.today.beginning_of_month #Leaves by month
    @month_end = Date.today.end_of_month   
    @date_today = Date.today
    @leave_year = Leave.find_by_sql("SELECT SUM(myview.days) AS no_leaves FROM (SELECT DATEDIFF(end_date, start_date) AS days FROM leaves WHERE user_id= #{current_id}  AND start_date >= '#{@year_start}' AND end_date <= '#{@date_today}') AS myview")
    @leave_month = Leave.find_by_sql("SELECT SUM(myview.days) AS no_leaves FROM (SELECT DATEDIFF(end_date, start_date) AS days FROM leaves WHERE user_id= #{current_id} AND start_date >= '#{@month_start}' AND end_date <= '#{@month_end}') AS myview")
    @by_month = @leave_month[0].no_leaves
    @by_year = @leave_year[0].no_leaves
    @leave_view = Leave.where(:user_id => current_id).order("status DESC")
    render 'leave/new' #END OF USER SIDE CODE
  end
#Update Method
  def update
    current_id = session[:user_id]
    @param_form = params[:param_user]
    @post = Leave.find(params[:id])
    @pre_startDate = @post.start_date
    @pre_endDate = @post.end_date
    if @post.update_attributes(params[:post])
      @post.update_attribute(:approver, session[:user_id])
      @post.update_attribute(:user_id, @param_form)
      if LeaveManagementSystemMailer.leave_rollback(User.current, @post,@pre_startDate,@pre_endDate).deliver
        flash[:notice]="Leave Record Rollaback Successfuly"
        redirect_to :action => :index
      else
        flash[:error]="Your internet connection has been down"
        redirect_to :action => :index
      end  
    end
  end
  #End Of Update Method
  def rollback
    @users_list = [] 
    User.all.each do |user| 
      if (user.type == 'User' && user.admin == false)
        @users_list.push(user.login)
      end
    end
    id = session[:user_id]
    @user_id = User.find(id)
    project = Project.where("name = 'Leave Management System'").first
    if (project) 
      member = Member.where("user_id = #{id} AND project_id = #{project.id}").first
      if (member)
        puts member.to_json
        role = MemberRole.where("member_id = #{member.id}").first
        puts role.to_json
        role = Role.find(role.role_id)
        puts role.to_json
      end
    end
    if @user_id.admin || (role && role.has_permission?("manage_members"))
      @leave_rollback = Leave.where(:status => "Approved")
      if params[:id]
        @post = Leave.find(params[:id])
        params_id = params[:id]
        @find = Leave.find(params_id)
        @p_id = @find.user_id
        @name = User.find(@p_id).login
        render 'leave/rollback' and return
      end
    else
      flash[:error] = "You have no admin rights..."
      redirect_to :action => :index and return
    end
  end

  def create #Start of create method
  	@leave_create = Leave.new(params[:post]) #Get parameters of form 
  	@leave_create.user_id = session[:user_id] #Store user id in Leave model
    @manager_id = params[:param_manager] #Get manager ID from user side
    if @leave_create.save  #Saving user data in Leave model
      @user_email = User.find(session[:user_id])
      @user_mail =  @user_email.mail
      @leave_create.update_attribute(:manager_id, @manager_id)
      @leave_create.update_attribute(:status, "Pending")
  		LeaveManagementSystemMailer.leave_email(User.current,@leave_create,@manager_id).deliver #Fire e-mail to manager and user
      flash[:notice]="Record saved "
      redirect_to :action => :new
    else
      flash[:error]="All fields must be filled " #If all forms are not filled record will not be save
      redirect_to :action => :new
  	end
  end # End of create method

  def index
   #Admin verification
   #@var5 = ActionController::Routing::Routes.recognize_path(request.url)[:id]

   @var4 = ActionController::Metal.controller_name
   #session[:cont] = params[:controller]
   #@op = controller_path()
   #@op = params[:status]
   session[:cont]
   @controller = params[:controller]
   #leave_ob = Leave.all
   #leave_ob.check_info(@controller)
   @test_var = 100


   
    #render 'leave/processed' and return
    if User.current.admin
      @admin_check = 1
    else
      @admin_check = 0
    end
    id = session[:user_id] #Get id of current user
    project = Project.where("name = 'Leave Management System'").first
    if (project) 
      member = Member.where("user_id = #{id} AND project_id = #{project.id}").first
      if (member)
        puts member.to_json
        role = MemberRole.where("member_id = #{member.id}").first
        puts role.to_json
        role = Role.find(role.role_id)
        puts role.to_json
      end
    end
    @user_id = User.find(id)
    @user_name = @user_id.name
    if @user_id.admin || (role && role.has_permission?("manage_members"))  #Admin side code
      if @admin_check == 1
        @leave = Leave.where("user_id != #{id} AND status = 'Pending'").all
        render 'leave/index' and return
      else
        redirect_to :action => :overview and return
        @leave = Leave.where("user_id != #{id} AND status = 'Pending' AND manager_id = #{id}")
        render 'leave/index' and return
      end

    else #User Side Code
      redirect_to :action => :new # Redirect the user to New Method
    end
  end # End of INDEX METHOD

  def processed #start Of Processed Method
    id = session[:user_id] #Get id of current user
    if User.current.admin
      @admin_check = 1
    else
      @admin_check = 0
    end
    @status_filter
    @leave_users
    @user_status_filter = params[:param_name]
    @user_name_filter = params[:param_user] 
    if @user_status_filter && @user_status_filter != ""
      @status_filter = Leave.where("user_id != #{id} AND status = '#{@user_status_filter}'").all
    end
    if @user_name_filter && @user_name_filter != ""
      @user_login = User.find_by_login(@user_name_filter)
      leave_id = @user_login.id
      @leave_users = Leave.find(:all , :conditions =>{ :user_id => leave_id }) 
    end
    if @leave_users 
      if @admin_check == 1
        @user_login = User.find_by_login(@user_name_filter)
        leave_id = @user_login.id
        @limit = 5
        @u_id = params[:param_uid]
        @leave_count = Leave.find(:all , :conditions => ["user_id != #{id} && user_id = #{leave_id}"]).count
        @leave_pages = Paginator.new @leave_count, @limit, params['page']
        @offset = @leave_pages.offset
        @leave_obj = Leave.find(:all , :conditions => ["user_id != #{id} && user_id = #{leave_id}"] , :offset => @offset, :limit => @limit)
        render 'leave/processed' and return
      else
        @user_login = User.find_by_login(@user_name_filter)
        leave_id = @user_login.id
        @limit = 5
        @u_id = params[:param_uid]
        @leave_count = Leave.find(:all , :conditions => ["user_id != #{id} && user_id = #{leave_id} && manager_id =#{id}"]).count
        @leave_pages = Paginator.new @leave_count, @limit, params['page']
        @offset = @leave_pages.offset
        @leave_obj = Leave.find(:all , :conditions => ["user_id != #{id} && user_id = #{leave_id} && manager_id = #{id}"] , :offset => @offset, :limit => @limit)
        render 'leave/processed' and return
        #render 'leave/index' and return
      end
    elsif @status_filter
      if @admin_check == 1
        @limit = 5
        @status_check = params[:param_status] 
        @leave_count = Leave.where("user_id != #{id} AND status = '#{@user_status_filter}'").count
        @leave_pages = Paginator.new @leave_count, @limit, params['page']
        @offset = @leave_pages.offset
        @leave_obj = Leave.find(:all , :conditions => ["user_id != #{id} && status = '#{@user_status_filter}'"], :offset => @offset, :limit => @limit)
        render 'leave/processed' and return
      else
        @limit = 5
        @status_check = params[:param_status] 
        @leave_count = Leave.where("user_id != #{id} AND status = '#{@user_status_filter}' AND manager_id = #{id}").count
        @leave_pages = Paginator.new @leave_count, @limit, params['page']
        @offset = @leave_pages.offset
        @leave_obj = Leave.find(:all , :conditions => ["user_id != #{id} && status = '#{@user_status_filter}' && manager_id = #{id}"], :offset => @offset, :limit => @limit)
        #render 'leave/index' and return
        render 'leave/processed' and return
      end
    else
      if @admin_check == 1
        @leave_count = Leave.find(:all , :conditions => ["user_id != #{id} && (status = 'Approved' || status = 'Disapproved')"]).count
        @limit = 10
        @leave_pages = Paginator.new @leave_count, @limit, params['page']
        @offset = @leave_pages.offset
        @leave_obj = Leave.find(:all , :conditions => ["user_id != #{id} && (status = 'Approved' || status = 'Disapproved')"] , :offset => @offset , :limit => @limit)
        render 'leave/processed' and return
      else
        @leave_count = Leave.find(:all , :conditions => ["manager_id = #{id} && user_id != #{id} && (status = 'Approved' || status = 'Disapproved')"]).count
        @limit = 5
        @leave_pages = Paginator.new @leave_count, @limit, params['page']
        @offset = @leave_pages.offset
        @leave_obj = Leave.find(:all , :conditions => ["manager_id = #{id} && user_id != #{id} && (status = 'Approved' || status = 'Disapproved')"] , :offset => @offset , :limit => @limit)
        render 'leave/processed' and return
       # render 'leave/index' and return
      end
    end
  end #End of Processed Method

  def decide
    @leave_decide = Leave.find(params[:id])
    @mail_id = @leave_decide.user_id 
    @mail_id = User.find(@mail_id)
    if params[:answer]=="yes"
      @leave_decide.update_attribute(:status, "Approved")
      @leave_decide.update_attribute(:approver, session[:user_id])
      @leave_decide.update_attribute(:approve_date , Date.today)
      @leave_decide.save
      LeaveManagementSystemMailer.leave_status(@mail_id, @leave_decide ,"Approved").deliver
      flash[:notice]="Leave Request Approved"
      redirect_to :action => 'index'
    else
      @leave_decide.update_attribute(:status, "Disapproved")
      @leave_decide.update_attribute(:approver, session[:user_id])
      @leave_decide.update_attribute(:approve_date , Date.today)
      @leave_decide.save
      LeaveManagementSystemMailer.leave_status(@mail_id, @leave_decide,"Disapproved").deliver
      flash[:notice]="Leave Request Disapproved"
      redirect_to :action => 'index'
    end
  end
end #End of Leave Controller