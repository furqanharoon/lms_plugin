class Leave < ActiveRecord::Base
	attr_accessible :start_date , :end_date , :request , :user_id , :approver , :approve_date , :leave_days , :status , :manager_id
	validates :request , presence: true,
                    length: { minimum: 5 ,:message => "Fill out leave description with appropriate details " }
    validates :leave_days , presence: true
   validates :start_date , presence: true
    validates :end_date , presence: true
    
    #def self.check_info(p)
    def self.check_info
        var4 = ActionController::Metal.controller_name
    	#puts p
    	#return true if p.nil?
        puts var4
        if var4.nil?
            return false
        else
            return true
        end

        #session[:cont]
    	#var2 = ActionDispatch::Request 

    	#var1 = ActionController::Routing::Routes.recognize_path(request.url)[:id]
    	
    	#session[:v1] = "gfgfgf"
    	#self.class.controller_name
    	#varc = ActionController::Metal.performed?

    	#varb = controller.controller_name
    	#Rails.controller
    	#@controller = params[:controller]

    	
    	#if var4
    	#	return true
    	#else
    	#	return false
    	#end
    end
end
 