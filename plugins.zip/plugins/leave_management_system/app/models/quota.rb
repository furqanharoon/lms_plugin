class Quota < ActiveRecord::Base
 attr_accessible :user_id, :quota
end
