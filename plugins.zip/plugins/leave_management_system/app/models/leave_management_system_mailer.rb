require 'mailer'
class LeaveManagementSystemMailer < ActionMailer::Base
  layout 'mailer'
  #default from: 'redmine@mindblaze.biz'
  default from: 'furqanharoon91@gmail.com'
  def leave_email(user,leave,manager)
    @manager = manager #Get manager id
    @leave = leave #Get object of LeaveRecord Of current user
    @leave_days = @leave.leave_days
    @leave_user = @leave.user_id #Get user id
    @leave_request = @leave.request
    @start_date = @leave.start_date
    @end_date = @leave.end_date
    @user = user
	  @name = @user.name
    @mail_check = User.where("id = #{@leave_user} OR id = #{@manager}").all
    @recipients = @mail_check.collect(&:mail).join(",")
    mail(to: @recipients, subject: 'Leave request submitted')do |format|
      format.html { render "leave_manager"}
    end
  end
  
  def leave_status(user,leave,status)
    @leave = leave
	  @status = status
  	@user = user
    @leave_days = @leave.leave_days
    @approver_id = @leave.approver
    @approver_name = User.find(@approver_id).name
    @approve_date = @leave.approve_date
	  @start_date = @leave.start_date
	  @end_date = @leave.end_date
    user_id = @leave.user_id
    @user_mail = User.find(user_id)
    @user_mail = @user_mail.mail
    @time = Time.now.strftime("%b %e %Y, %l:%M %p")
    
    mail(to: @user_mail, subject: "Leave request has been #{status.downcase}")do |format|
      format.html { render "leave_status"}
    end
  end
  
  def leave_rollback(user,leave,pre_startDate,pre_endDate)
    @pre_startDate = pre_startDate
    @pre_endDate = pre_endDate
    admin_mail = User.current.mail
    @user = user
    @leave = leave
    @status = @leave.status
    @approver_id = @leave.approver
    @approver_name = User.find(@approver_id).name
    user_id = @leave.user_id
    @user_mail = User.find(user_id)
    @user_mail = @user_mail.mail
    @leave_days = @leave.leave_days
    @start_date = @leave.start_date
    @end_date = @leave.end_date
    @time = Time.now.strftime("%b %e %Y, %l:%M %p")
    mail(to: @user_mail, subject: 'Leave Request Rollback')do |format|
      format.html { render "leave_rollback"}
    end
  end
end