class CreateLeaves < ActiveRecord::Migration
  def change
    create_table :leaves do |t|
      t.integer :user_id
      t.integer :manager_id
      t.string :status
      t.text :request
      t.date :start_date
      t.date :end_date
      t.integer :leave_days
      t.integer :approver
      t.date :approve_date
    end
  end
end
