class CreateQuota < ActiveRecord::Migration
  def change
    create_table :quota do |t|
      t.integer :user_id
      t.integer :quota
    end
  end
end
