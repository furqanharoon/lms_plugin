require 'redmine'
require 'rails/all'

Redmine::Plugin.register :leave_management_system do
  name 'Leave Management System plugin'
  author 'Furqan Haroon '
  description 'Leave Management System for Mindblazetech'
  version '0.0.1'
  url 'http://redmine.mindblazetech.com'
  author_url 'http://example.com/about'

  #puts params

  #menu :application_menu, :lms, { :controller => 'leave', :action => 'index' }, { :caption => 'Test', :if => Proc.new{ params[:controller] == 'leave'}}

 



menu :top_menu, :LeaveManagementSystem, { :controller => 'leave', :action => 'index' }, :caption => 'Leave Management System', :after => :activity, :param => :project_id , :if => Proc.new { User.current.logged? }

menu :application_menu, :Overview, {:controller => 'leave', :action => 'overview'}, :caption =>'Overview', :after => :activity, :param => :project_id , :if => Proc.new{ (User.current.logged? || (User.current.allowed_to?(:manage_members, nil, :global => true))) && !User.current.admin}
menu :application_menu, :Statistics, {:controller => 'leave', :action => 'processed'}, :caption =>'Processed' , :if => Proc.new{ (User.current.logged? && (User.current.allowed_to?(:manage_members, nil, :global => true))) || User.current.admin}
menu :application_menu, :LeaveManagementSystem, {:controller => 'leave', :action => 'new'}, :caption =>'Request Leave' , :if => Proc.new{ (User.current.logged? || (User.current.allowed_to?(:manage_members, nil, :global => true))) && !User.current.admin}

menu :application_menu, :LMS, {:controller => 'leave', :action => 'admin_side'}, :param => :project_id , :caption =>'Admin Side' , :if => Proc.new{Leave.check_info()}

#menu :application_menu, :LMS, {:controller => 'leave', :action => 'new'}, :caption =>'Testing' , :if => Proc.new {ActionController::Metal.controller_name == 'leave'}
#, :if => Proc.new {current_page?(controller: 'leave', action: 'index')}
#{controller.controller_name == 'Leave'}

#menu :application_menu, :info, {:controller=>'leave', :action=>'index'}, :caption=>'Ticker', :after=>:activity, :param=>:project_id, :if=>Proc.new{|p|Leave.check_info(p)}

#menu :application_menu, :leaves, {:controller=>'leave', :action=>'index'}, :caption => 'Ticker', :selected => false, :after =>:activity , :if => Proc.new {ActionController::Metal.controller_name == 'leave'} 

#menu :application_menu, :leaves, {:controller=>'leave', :action=>'index'}, :caption => 'Ticker', :selected => false, :after =>:activity , :if => Proc.new {:only => :index }

#menu :application_menu, :Leaves, {:controller => 'leave', :action => 'new'}, :only => :index , :caption => 'Ticker', :if => Proc.new{ User.current.logged? }


  project_module :leave_management_system do
    permission :view_leave, :leave => :index
  end
end



#ActionController::Metal.controller_name