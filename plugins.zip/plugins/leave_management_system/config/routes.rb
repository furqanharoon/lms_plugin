# Plugin's routes
# See: http://guides.rubyonrails.org/routing.html
get 'leave' , :to => 'leave#index'
post 'leave' , :to => 'leave#create'
match ':controller(/:action(/:id))(.:format)'